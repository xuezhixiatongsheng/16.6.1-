#import <Foundation/Foundation.h>
#import "../Sources/AVWGeometry.h"
#include <assert.h>

static void testScreen(CGFloat width, CGFloat height) {
    CGRect available = CGRectMake(8, 48, width - 16, height - 88);
    CGSize reference = CGSizeMake(width, height);
    for (int requested = -100; requested < 2000; requested += 7) {
        CGSize size = AVWWindowSize(requested, reference, available);
        assert(isfinite(size.width) && isfinite(size.height));
        assert(size.width > 0 && size.height > 44);
        assert(size.width <= available.size.width + 0.001);
        assert(size.height <= available.size.height + 0.001);
        assert(fabs((size.height - 44) / size.width - height / width) < 0.001);
        for (int x = -1000; x < 1000; x += 173) {
            CGRect frame = AVWConstrainFrame(CGRectMake(x, x * 2, size.width, size.height), available);
            assert(CGRectGetMinX(frame) >= CGRectGetMinX(available) - 0.001);
            assert(CGRectGetMinY(frame) >= CGRectGetMinY(available) - 0.001);
            assert(CGRectGetMaxX(frame) <= CGRectGetMaxX(available) + 0.001);
            assert(CGRectGetMaxY(frame) <= CGRectGetMaxY(available) + 0.001);
        }
    }
}
int main(void) {
    @autoreleasepool {
        testScreen(320, 568);
        testScreen(375, 667);
        testScreen(390, 844);
        testScreen(430, 932);
        CGRect screen = CGRectMake(0, 0, 375, 667);
        assert(AVWIsSwitcherCardFrame(CGRectMake(50, 83, 275, 490), screen));
        assert(AVWIsSwitcherCardFrame(CGRectMake(-220, 83, 275, 490), screen));
        assert(!AVWIsSwitcherCardFrame(screen, screen));
        assert(!AVWIsSwitcherCardFrame(CGRectMake(0, 0, 374, 660), screen));
        assert(!AVWIsSwitcherCardFrame(CGRectMake(400, 83, 275, 490), screen));
        assert(!AVWIsSwitcherCardFrame(CGRectZero, screen));
        assert(!AVWIsSwitcherCardFrame(CGRectMake(NAN, 83, 275, 490), screen));
        CGSize tiny = AVWWindowSize(400, CGSizeZero, CGRectMake(0, 0, 50, 100));
        assert(tiny.width <= 50 && tiny.height <= 100);
        puts("PASS: card/fullscreen visibility geometry, proportional resizing and screen clamping");
    }
    return 0;
}
