#import "AVWSceneSession.h"
#import <dlfcn.h>

static __weak AVWSceneSession *AVWCurrentSession;
static BOOL AVWHasSystemLiveMode;
static NSInteger AVWSystemLiveMode;

@interface AVWSceneSession ()
@property (nonatomic, strong, readwrite) UIView *hostView;
@property (nonatomic, strong, readwrite) id scene;
@property (nonatomic, strong) id handle;
@property (nonatomic, strong) id lastSystemSettings;
@property (nonatomic, copy, readwrite) NSString *bundleIdentifier;
@property (nonatomic, copy, readwrite) NSString *title;
@property (nonatomic, readwrite) CGSize referenceSize;
@property (nonatomic, readwrite) BOOL active;
@property (nonatomic) BOOL minimized;
@property (nonatomic) NSInteger liveMode;
@property (nonatomic) BOOL applyingOwnSettings;
- (void)applyOwnSettings:(id)settings;
@end

static id AVWForegroundSettings(id settings) {
    id copy = [settings mutableCopy];
    if (![copy respondsToSelector:@selector(setForeground:)] ||
        ![copy respondsToSelector:@selector(setBackgrounded:)] ||
        ![copy respondsToSelector:@selector(setOccluded:)]) return nil;
    [copy setForeground:YES];
    [copy setBackgrounded:NO];
    [copy setOccluded:NO];
    // Never clear deactivationReasons or underLock. System security policy wins.
    return copy;
}

@implementation AVWSceneSession
+ (instancetype)currentSession { return AVWCurrentSession; }

+ (void)observeSystemDisplayMode:(NSInteger)mode {
    NSString *(*modeName)(NSInteger) = dlsym(RTLD_DEFAULT, "NSStringFromSBSceneViewDisplayMode");
    NSString *name = modeName ? modeName(mode) : nil;
    NSString *lower = name.lowercaseString;
    if ([lower containsString:@"live"] && ![lower containsString:@"snapshot"]) {
        if (!AVWHasSystemLiveMode || AVWSystemLiveMode != mode) {
            os_log(AVWLog(), "Observed system live display mode=%ld name=%{public}@", (long)mode, name);
        }
        AVWSystemLiveMode = mode;
        AVWHasSystemLiveMode = YES;
    }
}

+ (BOOL)getSystemLiveDisplayMode:(NSInteger *)mode {
    if (!AVWHasSystemLiveMode) return NO;
    if (mode) *mode = AVWSystemLiveMode;
    return YES;
}

+ (instancetype)sessionWithHandle:(id)handle sourceWindow:(UIWindow *)window error:(NSString **)error {
    if (AVWLocked()) { if (error) *error = @"设备已锁定，不能打开小窗。"; return nil; }
    id app = AVWObject(handle, @"application");
    NSString *bundle = AVWObject(app, @"bundleIdentifier");
    // This prototype only borrows existing scenes. Do not invoke a possibly
    // scene-creating getter as a fallback or fabricate scene identifiers.
    id scene = AVWObject(handle, @"sceneIfExists");
    SEL create16 = @selector(newSceneViewWithReferenceSize:orientation:hostRequester:);
    SEL create17 = @selector(newSceneViewWithReferenceSize:contentOrientation:containerOrientation:hostRequester:);
    SEL chosen = NULL;
    // Validate every argument, not just CGSize. Never fall through to a selector
    // whose ABI differs from the declaration used by the call below.
    for (NSString *name in @[NSStringFromSelector(create16), NSStringFromSelector(create17)]) {
        SEL candidate = NSSelectorFromString(name);
        NSMethodSignature *signature = [handle methodSignatureForSelector:candidate];
        NSUInteger expected = candidate == create16 ? 5 : 6;
        if (!signature || signature.numberOfArguments != expected || signature.methodReturnType[0] != '@') continue;
        if (strcmp([signature getArgumentTypeAtIndex:2], @encode(CGSize)) != 0 ||
            strcmp([signature getArgumentTypeAtIndex:3], @encode(NSInteger)) != 0 ||
            [signature getArgumentTypeAtIndex:expected - 1][0] != '@') continue;
        if (candidate == create17 && strcmp([signature getArgumentTypeAtIndex:4], @encode(NSInteger)) != 0) continue;
        chosen = candidate;
        break;
    }
    BOOL canCreate = chosen != NULL;
    if (![bundle isKindOfClass:NSString.class] || !bundle.length || !scene || !canCreate) {
        if (error) *error = @"该卡片没有可托管的现有应用场景。请先打开应用，再进入多任务重试。";
        return nil;
    }
    if ([bundle isEqualToString:@"com.apple.springboard"] || [bundle isEqualToString:@"wiki.qaq.apelin"]) {
        if (error) *error = @"原型暂不托管桌面或 Apelin，请先用“设置”测试。";
        return nil;
    }
    NSInteger mode = 0;
    if (![self getSystemLiveDisplayMode:&mode]) {
        if (error) *error = @"尚未观察到系统的实时呈现模式。请先打开“设置”正常界面，再返回多任务重试。";
        return nil;
    }
    UIInterfaceOrientation orientation = window.windowScene.interfaceOrientation;
    if (orientation != UIInterfaceOrientationPortrait) {
        if (error) *error = @"首轮原型只验证竖屏，请切回竖屏后重试。";
        return nil;
    }
    CGSize size = window.screen.bounds.size;
    AVWSceneSession *session = [AVWSceneSession new];
    session.scene = scene;
    session.handle = handle;
    session.bundleIdentifier = bundle;
    session.title = AVWObject(app, @"displayName") ?: bundle;
    session.referenceSize = size;
    session.liveMode = mode;
    NSString *stage = @"copy-scene-settings";
    @try {
        session.lastSystemSettings = [AVWObject(scene, @"settings") copy];
        stage = NSStringFromSelector(chosen);
        os_log(AVWLog(), "Host factory class=%{public}@ selector=%{public}@ requesterClass=NSString build=%{public}s",
               NSStringFromClass([handle class]), stage, APELIN_BUILD_ID);
        if (chosen == create16) {
            session.hostView = [handle newSceneViewWithReferenceSize:size orientation:orientation hostRequester:@"AvocadoWindows.Prototype"];
        } else {
            session.hostView = [handle newSceneViewWithReferenceSize:size contentOrientation:orientation containerOrientation:orientation hostRequester:@"AvocadoWindows.Prototype"];
        }
    } @catch (NSException *exception) {
        os_log_error(AVWLog(), "Host creation exception stage=%{public}@ name=%{public}@ reason=%{private}@ build=%{public}s",
                     stage, exception.name, exception.reason, APELIN_BUILD_ID);
        NSString *reason = exception.reason ?: @"系统未提供原因";
        if (reason.length > 240) reason = [[reason substringToIndex:240] stringByAppendingString:@"…"];
        if (error) *error = [NSString stringWithFormat:@"创建宿主失败（%@）。\n阶段：%@\n原因：%@\n构建：%s", exception.name, stage, reason, APELIN_BUILD_ID];
        // A factory may have returned a partially initialized view before a later
        // operation fails. Release our resources without changing other scenes.
        [session stop];
        return nil;
    }
    if (![session.hostView isKindOfClass:UIView.class] ||
        ![session.hostView respondsToSelector:@selector(setDisplayMode:animationFactory:completion:)] ||
        ![session.hostView respondsToSelector:@selector(invalidate)] ||
        ![scene respondsToSelector:@selector(updateSettings:withTransitionContext:completion:)]) {
        [session stop];
        if (error) *error = @"此系统的宿主接口与原型不匹配，需要进一步适配。";
        return nil;
    }
    return session;
}

- (BOOL)start:(NSString **)error {
    if (AVWLocked() || !self.hostView.window) {
        if (error) *error = @"场景尚未接入窗口或设备已锁定。";
        return NO;
    }
    id settings = AVWForegroundSettings(AVWObject(self.scene, @"settings"));
    if (!settings) { if (error) *error = @"场景设置接口不可用。"; return NO; }
    @try {
        self.active = YES;
        AVWCurrentSession = self;
        [self applyOwnSettings:settings];
        if ([self.hostView respondsToSelector:@selector(setResizesHostedContext:)]) [(id)self.hostView setResizesHostedContext:NO];
        if ([self.hostView respondsToSelector:@selector(setActive:)]) [(id)self.hostView setActive:YES];
        if ([self.hostView respondsToSelector:@selector(setVisible:)]) [(id)self.hostView setVisible:YES];
        [(id)self.hostView setDisplayMode:self.liveMode animationFactory:nil completion:nil];
        [self.hostView setNeedsLayout];
        [self.hostView layoutIfNeeded];
        os_log(AVWLog(), "Host requested for %{public}@; image and input not yet verified", self.bundleIdentifier);
        return YES;
    } @catch (NSException *exception) {
        os_log_error(AVWLog(), "Host activation exception %{public}@", exception.name);
        [self stop];
        if (error) *error = @"宿主激活失败，已撤销小窗。";
        return NO;
    }
}

- (void)applyOwnSettings:(id)settings {
    self.applyingOwnSettings = YES;
    @try { [self.scene updateSettings:settings withTransitionContext:nil completion:nil]; }
    @finally { self.applyingOwnSettings = NO; }
}

- (id)settingsForSystemRequest:(id)settings {
    if (!self.active || self.applyingOwnSettings) return settings;
    self.lastSystemSettings = [settings copy];
    if (self.minimized || AVWLocked()) return settings;
    return AVWForegroundSettings(settings) ?: settings;
}

- (void)setMinimized:(BOOL)minimized {
    _minimized = minimized;
    @try {
        if (minimized && self.lastSystemSettings) {
            [self.scene updateSettings:self.lastSystemSettings withTransitionContext:nil completion:nil];
        } else if (!minimized && !AVWLocked()) {
            id settings = AVWForegroundSettings(AVWObject(self.scene, @"settings"));
            if (settings) [self applyOwnSettings:settings];
        }
        if ([self.hostView respondsToSelector:@selector(setVisible:)]) [(id)self.hostView setVisible:!minimized];
    } @catch (NSException *exception) { os_log_error(AVWLog(), "Minimize transition exception %{public}@", exception.name); }
}

- (void)stop {
    BOOL restore = self.active;
    self.active = NO;
    if (AVWCurrentSession == self) AVWCurrentSession = nil;
    self.hostView.userInteractionEnabled = NO;
    @try {
        if ([self.hostView respondsToSelector:@selector(setVisible:)]) [(id)self.hostView setVisible:NO];
        if ([self.hostView respondsToSelector:@selector(setActive:)]) [(id)self.hostView setActive:NO];
        if ([self.hostView respondsToSelector:@selector(invalidate)]) [(id)self.hostView invalidate];
        if (restore && !AVWLocked() && self.lastSystemSettings) {
            [self.scene updateSettings:self.lastSystemSettings withTransitionContext:nil completion:nil];
        }
    } @catch (NSException *exception) { os_log_error(AVWLog(), "Host cleanup exception %{public}@", exception.name); }
    [self.hostView removeFromSuperview];
    self.hostView = nil;
    self.scene = nil;
    self.handle = nil;
    self.lastSystemSettings = nil;
}
@end
