# Development instructions

This is an external-build Objective-C workspace, not a Theos project. Read Docs/Requirements.md before changing the UX. The app-switcher action belongs at the **upper-right** of each app card.

## Build
- The prepared CLT toolchain and iPhoneOS SDK are supplied by Apelin. The initial environment uses CLT 16.4 and iPhoneOS SDK 16.4, targeting iOS 16.0+.
- Build/installable packages **only** with `apelin_project_build`, which runs BuildSupport/build.sh. Never run that packaging script directly from shell_run or make a package by hand.
- Script requires Apelin's build variables; all compile paths are relative. It compiles arm64e for roothide, arm64 + arm64e for rootless, generates a dSYM, signs the final dylib, and writes one package into APELIN_PACKAGE_DIR.
- Package metadata is Packaging/control. The user confirmed retaining `local.apelin.avocado.windows`; this ID is now installed and must remain the same for debug/release. Do not change it without an agreed migration.
- Substrate-compatible hooks first resolve MSHookMessageEx from the injection process; if unavailable, load the installed compatibility library with `ApelinBootstrapPath` and keep its handle open. The package still depends on mobilesubstrate; no private frameworks are linked. Startup entry diagnostics are logged every five seconds for about two minutes after a respring.

## Test helpers
Run these from the project root using shell_run; the executables must be signed again after every link:

```
clang -arch arm64e -miphoneos-version-min=16.0 -fobjc-arc -Wall -Wextra -Werror -framework Foundation -framework CoreGraphics Tests/GeometryTests.m -o Tests/geometry-tests
ldid -STools/Tool.entitlements Tests/geometry-tests
./Tests/geometry-tests
```

Tools/InspectRuntime.m is a **read-only** method enumerator. Compile against Foundation, sign with Tools/Tool.entitlements, then run with class names. It may load FrontBoard and UIKit. **Never add SpringBoard or SpringBoardUI to its dlopen list:** SpringBoardUI asserts when loaded by a standalone process. Those classes must be checked inside SpringBoard instead.

## Prototype architecture and limitations
- Sources/Tweak.m adds a button to SBAppSwitcherPageView and conditionally intercepts only the current floating scene's settings. On this device the card content is `SBAppSwitcherReusableSnapshotView`, not a live scene view: use its `appLayout` (or the ancestor container's layout) to identify a single app. Re-resolve at tap time, obtain the exact layout role's scene handle or ask the system to map the display item's unique identifier to an existing scene. Never equate a unique identifier with a scene ID or host the snapshot as interactive content.
- AVWSceneSession reuses an existing application scene; it does not create/destroy sessions or kill apps. It creates its own scene view using the handle, preferring iOS 16's `newSceneViewWithReferenceSize:orientation:hostRequester:` and checking the newer four-argument selector only as a fallback. The live display mode is learned by observing actual system calls to `SBSceneView setDisplayMode:animationFactory:completion:` and validating the name with `NSStringFromSBSceneViewDisplayMode` (live, not snapshot). Do not require a snapshot card to contain a live view. If no live mode was observed, show a clear diagnostic and ask the user to open Settings normally before returning to the switcher.
- AVWWindowController owns the transparent non-key overlay, window chrome, proportional resizing and a fading edge bubble. Lock notifications close it; landscape also closes it in this first prototype.
- Locks and deactivation reasons are not cleared. Scene foreground flags alone do not prove input works. Sidebars, app selection, cold launch and split-screen are **not implemented** yet. The bubble currently shows an abbreviated app title, not its app icon. Resize is a corner drag, not pinch.
- All scene hosting, card appearance, input, title-bar actions, minimize, fade and lock cleanup remain **unverified on the device** until installed and exercised. A successful build is not evidence they work.
- First device test should use Settings, never Apelin. Obtain screen consent first, install only after confirming the identifier, then use apelin_package_confirm_loaded with respring=true. Inspect card and window UI using screen tools; ask separately for each screenshot. Verify real controls respond, scrolling and touch alignment before adding more UX.
- Keep the load marker and use os_log under APELIN_PACKAGE_ID. Heartbeats report host state every five seconds while a window exists, not proof of interactive success.

## History
Commit changes after a successful build with the git tools. Never push without a user request. Generated tools and .build are ignored. Never persist a resolved roothide install path.
