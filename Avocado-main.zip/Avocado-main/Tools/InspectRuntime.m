#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <dlfcn.h>

// Read-only: enumerate selectors without creating or changing scene objects.
int main(int argc, const char *argv[]) {
    @autoreleasepool {
        const char *frameworks[] = {
            "/System/Library/PrivateFrameworks/FrontBoard.framework/FrontBoard",
            "/System/Library/Frameworks/UIKit.framework/UIKit"
        };
        for (unsigned i = 0; i < sizeof(frameworks)/sizeof(frameworks[0]); i++) {
            if (!dlopen(frameworks[i], RTLD_LAZY | RTLD_LOCAL)) {
                fprintf(stderr, "Unable to load %s: %s\n", frameworks[i], dlerror());
            }
        }
        NSMutableDictionary *result = [NSMutableDictionary dictionary];
        for (int i = 1; i < argc; i++) {
            NSString *name = @(argv[i]);
            Class cls = objc_getClass(argv[i]);
            if (!cls) { result[name] = @{ @"available": @NO }; continue; }
            NSMutableArray *methods = [NSMutableArray array];
            for (unsigned meta = 0; meta < 2; meta++) {
                unsigned count = 0;
                Method *list = class_copyMethodList(meta ? object_getClass(cls) : cls, &count);
                for (unsigned j = 0; j < count; j++) {
                    [methods addObject:@{ @"kind": meta ? @"+" : @"-", @"selector": NSStringFromSelector(method_getName(list[j])), @"encoding": @(method_getTypeEncoding(list[j])) }];
                }
                free(list);
            }
            result[name] = @{ @"available": @YES, @"superclass": NSStringFromClass(class_getSuperclass(cls)) ?: @"", @"methods": methods };
        }
        NSData *json = [NSJSONSerialization dataWithJSONObject:result options:NSJSONWritingPrettyPrinted | NSJSONWritingSortedKeys error:nil];
        fwrite(json.bytes, 1, json.length, stdout);
        puts("");
    }
    return 0;
}
