# Avocado：iOS 16 小窗原型

这是独立的小窗工程，GSA 项目位于另一个仓库：<https://github.com/xuezhixiatongsheng/GSA->。

## 目录

- `Sources/`、`Packaging/`、`BuildSupport/`：Apelin 外部构建工程，保留已安装包名 `local.apelin.avocado.windows`。
- `apelin-project.json`：Apelin 工程配置。
- `Docs/Requirements.md`：原始需求与未实现功能。
- `Docs/DeviceValidation.md`：0.1.4 修改说明与手机验证步骤。
- `scripts/`、`debs/`、`depictions/`：从误用的 GSA 仓库迁入的软件源配置。
- `Archives/`：原始导出包与历史恢复资料。不要把其中旧代码覆盖到当前工作区。

## 当前状态：0.1.4，待手机验收

入口增加多任务状态、卡片可见性及全屏尺寸检查；多任务退出时隐藏按钮，点击时再次校验当前卡片。宿主工厂检查全部参数 ABI，接口不匹配时拒绝调用；失败信息包含阶段、异常名称、原因和构建编号。

宿主创建异常的根因仍需要手机运行结果确认。没有用快照冒充可交互应用，也没有把“编译通过”视作小窗可用。侧边栏、冷启动、分屏等仍未实现。

## 构建与安装

使用手机 Apelin 的 `apelin_project_build` 构建；不要直接执行 `BuildSupport/build.sh`，不要手工拼装安装包。Windows 不具备 Apelin 的 iPhoneOS 签名、打包及设备环境。GitHub CI 仅做 SDK 语法检查和几何单元测试，不生成可安装 deb。

首次设备测试使用“设置”。具体步骤见 `Docs/DeviceValidation.md`。旧截图对应 0.1.3，不能作为 0.1.4 的验收证据。

软件源原先没有 deb 文件；迁移没有生成或发布新安装包。仓库保持私有，GitHub Pages 尚未启用。需要分发软件源时再配置 Pages 和可安装包，不使用 GSA 的旧路径。
