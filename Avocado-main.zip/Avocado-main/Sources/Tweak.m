#import "AVWWindowController.h"
#import <objc/runtime.h>
#import <dlfcn.h>
#import <notify.h>
#import "ApelinBootstrap.h"
#import "AVWGeometry.h"

typedef void (*AVWHookMessageFunction)(Class cls, SEL selector, IMP replacement, IMP *original);
static void (*AVWOriginalPageLayout)(UIView *, SEL);
static void (*AVWOriginalPageDidMoveToWindow)(UIView *, SEL);
static void (*AVWOriginalSceneUpdate)(id, SEL, id, id, id);
static void (*AVWOriginalSetDisplayMode)(id, SEL, NSInteger, id, id);
static char AVWPageButtonKey;
static BOOL AVWHookWasGlobal;
static BOOL AVWPageHookInstalled;
static BOOL AVWSceneHookInstalled;
static NSUInteger AVWLayoutCount;
static NSUInteger AVWEligibleCount;
static NSString *AVWLastContentClass = @"none";
static NSString *AVWLastEntryReason = @"no-layout";
static NSString *AVWHookLibrary = @"unresolved";
static NSInteger AVWRuntimeMajorVersion;
static void (*AVWOriginalSwitcherDidAppear)(UIViewController *, SEL, BOOL);
static void (*AVWOriginalSwitcherDidDisappear)(UIViewController *, SEL, BOOL);
static NSHashTable<UIView *> *AVWTrackedPages;
static CADisplayLink *AVWEntryDisplayLink;

// Read the system switcher state with ABI validation. A reused page can remain
// attached while its app is fullscreen, so page.window alone is insufficient.
static BOOL AVWSwitcherVisible(void) {
    id controller = AVWObject(NSClassFromString(@"SBMainSwitcherViewController"), @"sharedInstance");
    SEL selector = NSSelectorFromString(@"isMainSwitcherVisible");
    NSMethodSignature *signature = [controller methodSignatureForSelector:selector];
    if (!signature || signature.numberOfArguments != 2 ||
        (signature.methodReturnType[0] != 'B' && signature.methodReturnType[0] != 'c')) return NO;
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    invocation.target = controller;
    invocation.selector = selector;
    [invocation invoke];
    BOOL visible = NO;
    [invocation getReturnValue:&visible];
    return visible;
}

static BOOL AVWPageIsVisibleCard(UIView *page) {
    if (!page.window || AVWLocked() || !AVWSwitcherVisible()) return NO;
    for (UIView *ancestor = page; ancestor; ancestor = ancestor.superview) {
        if (ancestor.hidden || ancestor.alpha < 0.01) return NO;
    }
    CGRect frame = [page convertRect:page.bounds toView:page.window];
    CGRect bounds = page.window.bounds;
    // Hide during expansion to fullscreen and reject non-card/zero-size views.
    return AVWIsSwitcherCardFrame(frame, bounds);
}

@interface AVWEntryMonitor : NSObject
+ (void)tick:(CADisplayLink *)link;
@end
@implementation AVWEntryMonitor
+ (void)tick:(CADisplayLink *)link {
    BOOL anyVisible = NO;
    for (UIView *page in AVWTrackedPages.allObjects) {
        UIButton *button = objc_getAssociatedObject(page, &AVWPageButtonKey);
        if (button.hidden) continue;
        if (!AVWPageIsVisibleCard(page)) button.hidden = YES;
        else anyVisible = YES;
    }
    if (!anyVisible) {
        [link invalidate];
        AVWEntryDisplayLink = nil;
    }
}
@end

static void AVWMonitorVisibleEntries(UIView *page) {
    if (!AVWTrackedPages) AVWTrackedPages = [NSHashTable weakObjectsHashTable];
    [AVWTrackedPages addObject:page];
    if (AVWEntryDisplayLink) return;
    AVWEntryDisplayLink = [CADisplayLink displayLinkWithTarget:AVWEntryMonitor.class selector:@selector(tick:)];
    AVWEntryDisplayLink.preferredFramesPerSecond = 15;
    [AVWEntryDisplayLink addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];
}

static void AVWSwitcherDidAppear(UIViewController *controller, SEL selector, BOOL animated) {
    AVWOriginalSwitcherDidAppear(controller, selector, animated);
    // Entry state can change after the last card layout during the transition.
    for (UIView *page in AVWTrackedPages.allObjects) [page setNeedsLayout];
}

static void AVWSwitcherDidDisappear(UIViewController *controller, SEL selector, BOOL animated) {
    AVWOriginalSwitcherDidDisappear(controller, selector, animated);
    for (UIView *page in AVWTrackedPages.allObjects) {
        UIButton *button = objc_getAssociatedObject(page, &AVWPageButtonKey);
        button.hidden = YES;
    }
    [AVWEntryDisplayLink invalidate];
    AVWEntryDisplayLink = nil;
}

static AVWHookMessageFunction AVWResolveHook(void) {
    AVWHookMessageFunction hook = (AVWHookMessageFunction)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
    AVWHookWasGlobal = hook != NULL;
    if (hook) { AVWHookLibrary = @"global"; return hook; }
    // Injection of this dylib does not guarantee that a compatibility API has
    // been loaded into the global symbol namespace. Keep the image open.
    static void *library;
    for (NSString *logicalPath in @[@"/usr/lib/libellekit.dylib", @"/usr/lib/libsubstrate.dylib"]) {
        NSString *path = ApelinBootstrapPath(logicalPath);
        if (!path) continue;
        library = dlopen(path.fileSystemRepresentation, RTLD_NOW | RTLD_LOCAL);
        if (!library) continue;
        hook = (AVWHookMessageFunction)dlsym(library, "MSHookMessageEx");
        if (hook) { AVWHookLibrary = logicalPath.lastPathComponent; return hook; }
        dlclose(library);
        library = NULL;
    }
    return NULL;
}

static void AVWLogEntryState(void) {
    os_log(AVWLog(), "Entry diagnostics osMajor=%ld globalHook=%d library=%{public}@ pageHook=%d sceneHook=%d liveKnown=%d layouts=%lu eligible=%lu content=%{public}@ reason=%{public}@ build=%{public}s",
           (long)AVWRuntimeMajorVersion, AVWHookWasGlobal, AVWHookLibrary, AVWPageHookInstalled, AVWSceneHookInstalled,
           [AVWSceneSession getSystemLiveDisplayMode:NULL],
           (unsigned long)AVWLayoutCount, (unsigned long)AVWEligibleCount,
           AVWLastContentClass, AVWLastEntryReason, APELIN_BUILD_ID);
}

static void AVWBeginEntryDiagnostics(void) {
    // Bounded startup diagnostics: long enough for confirm_loaded then log_read,
    // without persistent log files or dumping app contents/scene identifiers.
    static dispatch_source_t timer;
    timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), 5 * NSEC_PER_SEC, NSEC_PER_SEC / 2);
    __block NSUInteger ticks = 0;
    dispatch_source_set_event_handler(timer, ^{
        AVWLogEntryState();
        if (++ticks >= 24) { dispatch_source_cancel(timer); timer = nil; }
    });
    dispatch_resume(timer);
}

static void AVWPageDidMoveToWindow(UIView *page, SEL selector) {
    AVWOriginalPageDidMoveToWindow(page, selector);
    [page setNeedsLayout];
}

static UIView *AVWFindSource(UIView *view, NSUInteger depth) {
    if (!view || depth > 6) return nil;
    if (AVWObject(view, @"sceneHandle")) return view;
    for (UIView *child in view.subviews) {
        UIView *found = AVWFindSource(child, depth + 1);
        if (found) return found;
    }
    return nil;
}

static UIView *AVWSourceForPage(UIView *page) {
    id content = AVWObject(page, @"view");
    return [content isKindOfClass:UIView.class] ? AVWFindSource(content, 0) : nil;
}

static BOOL AVWCallSignature(id target, SEL selector, NSUInteger count, char result) {
    if (![target respondsToSelector:selector]) return NO;
    NSMethodSignature *signature = [target methodSignatureForSelector:selector];
    return signature && signature.numberOfArguments == count && signature.methodReturnType[0] == result;
}

static id AVWCallObject(id target, NSString *name, NSArray *arguments) {
    SEL selector = NSSelectorFromString(name);
    if (!AVWCallSignature(target, selector, arguments.count + 2, '@')) return nil;
    NSMethodSignature *signature = [target methodSignatureForSelector:selector];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    invocation.target = target;
    invocation.selector = selector;
    for (NSUInteger i = 0; i < arguments.count; i++) {
        if ([signature getArgumentTypeAtIndex:i + 2][0] != '@') return nil;
        id argument = arguments[i] == NSNull.null ? nil : arguments[i];
        [invocation setArgument:&argument atIndex:i + 2];
    }
    [invocation invoke];
    __unsafe_unretained id result = nil;
    [invocation getReturnValue:&result];
    return result;
}

static id AVWLayoutForPage(UIView *page) {
    id content = AVWObject(page, @"view");
    id layout = AVWObject(content, @"appLayout");
    for (UIView *ancestor = page.superview; !layout && ancestor; ancestor = ancestor.superview) {
        layout = AVWObject(ancestor, @"appLayout");
    }
    return layout;
}

static id AVWItemForPage(UIView *page) {
    id items = AVWObject(AVWLayoutForPage(page), @"allItems");
    if ([items isKindOfClass:NSSet.class]) items = [items allObjects];
    if (![items isKindOfClass:NSArray.class] || [items count] != 1) return nil;
    return [items firstObject];
}

static NSString *AVWBundleForPage(UIView *page) {
    NSString *bundle = AVWObject(AVWItemForPage(page), @"bundleIdentifier");
    if (!bundle) {
        id handle = AVWObject(AVWSourceForPage(page), @"sceneHandle");
        bundle = AVWObject(AVWObject(handle, @"application"), @"bundleIdentifier");
    }
    return [bundle isKindOfClass:NSString.class] ? bundle : nil;
}

static BOOL AVWHandleMatchesBundle(id handle, NSString *bundle) {
    NSString *actual = AVWObject(AVWObject(handle, @"application"), @"bundleIdentifier");
    return bundle.length && [actual isEqualToString:bundle];
}

static id AVWHandleForPage(UIView *page) {
    NSString *bundle = AVWBundleForPage(page);
    id handle = AVWObject(AVWSourceForPage(page), @"sceneHandle");
    if (AVWHandleMatchesBundle(handle, bundle)) return handle;
    id content = AVWObject(page, @"view");
    id layout = AVWLayoutForPage(page);
    id item = AVWItemForPage(page);
    // A snapshot may expose the real scene handle for the exact layout role.
    // Obtain that role from the layout; do not guess magic role constants.
    SEL roleSelector = @selector(layoutRoleForItem:);
    SEL handleSelector = @selector(_sceneHandleForRole:);
    if (item && AVWCallSignature(layout, roleSelector, 3, 'q') &&
        AVWCallSignature(content, handleSelector, 3, '@')) {
        NSMethodSignature *roleSignature = [layout methodSignatureForSelector:roleSelector];
        NSMethodSignature *handleSignature = [content methodSignatureForSelector:handleSelector];
        if ([roleSignature getArgumentTypeAtIndex:2][0] == '@' && [handleSignature getArgumentTypeAtIndex:2][0] == 'q') {
            NSInteger role = [layout layoutRoleForItem:item];
            handle = [content _sceneHandleForRole:role];
            if (AVWHandleMatchesBundle(handle, bundle)) return handle;
        }
    }
    // Ask the system to map the display item's unique identity. It is NOT
    // assumed to equal a scene identifier, and no scene is created here.
    NSString *unique = AVWObject(item, @"uniqueIdentifier");
    if (![unique isKindOfClass:NSString.class] || !unique.length || !bundle.length) return nil;
    id manager = AVWObject(NSClassFromString(@"SBSceneManagerCoordinator"), @"mainDisplaySceneManager");
    NSString *sceneID = AVWCallObject(manager, @"sceneIdentifierForBundleIdentifier:uniqueIdentifier:", @[bundle, unique]);
    if (![sceneID isKindOfClass:NSString.class] || !sceneID.length) return nil;
    id fbManager = AVWObject(NSClassFromString(@"FBSceneManager"), @"sharedInstance");
    id scene = AVWCallObject(fbManager, @"sceneWithIdentifier:", @[sceneID]);
    if (!scene) return nil;
    handle = AVWCallObject(manager, @"existingSceneHandleForScene:", @[scene]);
    return AVWHandleMatchesBundle(handle, bundle) ? handle : nil;
}

static void AVWPageLayout(UIView *page, SEL selector) {
    AVWOriginalPageLayout(page, selector);
    if (!AVWTrackedPages) AVWTrackedPages = [NSHashTable weakObjectsHashTable];
    [AVWTrackedPages addObject:page];
    AVWLayoutCount++;
    id content = AVWObject(page, @"view");
    AVWLastContentClass = content ? NSStringFromClass([content class]) : @"nil";
    UIButton *button = objc_getAssociatedObject(page, &AVWPageButtonKey);
    NSString *bundle = AVWBundleForPage(page);
    BOOL eligible = AVWPageIsVisibleCard(page) && bundle.length &&
        ![bundle isEqualToString:@"wiki.qaq.apelin"] && ![bundle isEqualToString:@"com.apple.springboard"];
    if (!eligible) {
        AVWLastEntryReason = !AVWPageIsVisibleCard(page) ? @"not-visible-switcher-card" : (!bundle.length ? @"no-card-application" : @"excluded-application");
        button.hidden = YES;
        return;
    }
    AVWEligibleCount++;
    AVWLastEntryReason = @"button-visible";
    if (!button) {
        button = [UIButton buttonWithType:UIButtonTypeSystem];
        [button setImage:[UIImage systemImageNamed:@"rectangle.inset.filled"] forState:UIControlStateNormal];
        button.tintColor = UIColor.whiteColor;
        button.backgroundColor = [UIColor colorWithWhite:0.12 alpha:0.9];
        button.layer.cornerRadius = 18;
        button.accessibilityLabel = @"以小窗打开应用";
        button.accessibilityIdentifier = @"avw.openWindow";
        // Resolve the page's current content at tap time; switcher cells are reused.
        __weak UIView *weakPage = page;
        [button addAction:[UIAction actionWithHandler:^(UIAction *action) {
            UIView *currentPage = weakPage;
            NSString *currentBundle = AVWBundleForPage(currentPage);
            if (!AVWPageIsVisibleCard(currentPage) || !currentBundle.length || [currentBundle isEqualToString:@"wiki.qaq.apelin"] || [currentBundle isEqualToString:@"com.apple.springboard"]) return;
            id handle = nil;
            @try { handle = AVWHandleForPage(currentPage); }
            @catch (NSException *exception) { os_log_error(AVWLog(), "Card lookup exception %{public}@", exception.name); }
            os_log(AVWLog(), "Card action existingHandle=%d liveModeKnown=%d", handle != nil, [AVWSceneSession getSystemLiveDisplayMode:NULL]);
            [[AVWWindowController shared] openSceneHandle:handle fromWindow:currentPage.window];
        }] forControlEvents:UIControlEventTouchUpInside];
        objc_setAssociatedObject(page, &AVWPageButtonKey, button, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [page addSubview:button];
    }
    button.hidden = NO;
    AVWMonitorVisibleEntries(page);
    button.frame = CGRectMake(MAX(0, page.bounds.size.width - 46), 10, 36, 36);
    [page bringSubviewToFront:button];
}

static void AVWSetDisplayMode(id view, SEL selector, NSInteger mode, id factory, id completion) {
    if (NSThread.isMainThread) [AVWSceneSession observeSystemDisplayMode:mode];
    AVWOriginalSetDisplayMode(view, selector, mode, factory, completion);
}

static void AVWSceneUpdate(id scene, SEL selector, id settings, id context, id completion) {
    id effective = settings;
    // Scene layout is expected on the main thread; never synchronously dispatch here.
    if (NSThread.isMainThread) {
        AVWSceneSession *session = AVWSceneSession.currentSession;
        if (session.scene == scene && settings) {
            @try { effective = [session settingsForSystemRequest:settings]; }
            @catch (NSException *exception) {
                os_log_error(AVWLog(), "Settings interception exception %{public}@", exception.name);
                effective = settings;
            }
        }
    }
    AVWOriginalSceneUpdate(scene, selector, effective, context, completion);
}

static BOOL AVWCompatibleMethod(Class cls, SEL selector, unsigned count, char resultType) {
    Method method = class_getInstanceMethod(cls, selector);
    if (!method || method_getNumberOfArguments(method) != count) return NO;
    char *type = method_copyReturnType(method);
    BOOL valid = type && type[0] == resultType;
    free(type);
    return valid;
}

__attribute__((constructor)) static void AVWInitialize(void) {
    os_log(AVWLog(), "ApelinLoaded %{public}s", APELIN_BUILD_ID);
    dispatch_async(dispatch_get_main_queue(), ^{
        AVWBeginEntryDiagnostics();
        AVWRuntimeMajorVersion = NSProcessInfo.processInfo.operatingSystemVersion.majorVersion;
        if (AVWRuntimeMajorVersion != 16) {
            AVWLastEntryReason = @"unsupported-system-version";
            AVWLogEntryState();
            return;
        }
        AVWHookMessageFunction hook = AVWResolveHook();
        Class pageClass = NSClassFromString(@"SBAppSwitcherPageView");
        Class sceneClass = NSClassFromString(@"FBScene");
        SEL update = @selector(updateSettings:withTransitionContext:completion:);
        if (!hook) {
            AVWLastEntryReason = @"missing-hook-function";
            AVWLogEntryState();
            return;
        }
        Class switcherClass = NSClassFromString(@"SBMainSwitcherViewController");
        if ([switcherClass isSubclassOfClass:UIViewController.class]) {
            SEL appeared = @selector(viewDidAppear:);
            SEL disappeared = @selector(viewDidDisappear:);
            NSMethodSignature *appearSignature = [switcherClass instanceMethodSignatureForSelector:appeared];
            NSMethodSignature *disappearSignature = [switcherClass instanceMethodSignatureForSelector:disappeared];
            if (AVWCompatibleMethod(switcherClass, appeared, 3, 'v') &&
                strcmp([appearSignature getArgumentTypeAtIndex:2], @encode(BOOL)) == 0) {
                hook(switcherClass, appeared, (IMP)AVWSwitcherDidAppear, (IMP *)&AVWOriginalSwitcherDidAppear);
            }
            if (AVWCompatibleMethod(switcherClass, disappeared, 3, 'v') &&
                strcmp([disappearSignature getArgumentTypeAtIndex:2], @encode(BOOL)) == 0) {
                hook(switcherClass, disappeared, (IMP)AVWSwitcherDidDisappear, (IMP *)&AVWOriginalSwitcherDidDisappear);
            }
        }
        Class sceneViewClass = NSClassFromString(@"SBSceneView");
        SEL displayModeSelector = @selector(setDisplayMode:animationFactory:completion:);
        NSMethodSignature *modeSignature = [sceneViewClass instanceMethodSignatureForSelector:displayModeSelector];
        if (AVWCompatibleMethod(sceneViewClass, displayModeSelector, 5, 'v') && [modeSignature getArgumentTypeAtIndex:2][0] == 'q') {
            hook(sceneViewClass, displayModeSelector, (IMP)AVWSetDisplayMode, (IMP *)&AVWOriginalSetDisplayMode);
        }
        if (AVWCompatibleMethod(sceneClass, update, 5, 'v')) {
            hook(sceneClass, update, (IMP)AVWSceneUpdate, (IMP *)&AVWOriginalSceneUpdate);
            AVWSceneHookInstalled = AVWOriginalSceneUpdate != NULL;
        }
        if (AVWCompatibleMethod(pageClass, @selector(layoutSubviews), 2, 'v')) {
            hook(pageClass, @selector(layoutSubviews), (IMP)AVWPageLayout, (IMP *)&AVWOriginalPageLayout);
            AVWPageHookInstalled = AVWOriginalPageLayout != NULL;
            if (AVWCompatibleMethod(pageClass, @selector(didMoveToWindow), 2, 'v')) {
                hook(pageClass, @selector(didMoveToWindow), (IMP)AVWPageDidMoveToWindow, (IMP *)&AVWOriginalPageDidMoveToWindow);
            }
        }
        if (!AVWPageHookInstalled) AVWLastEntryReason = @"page-hook-unavailable";
        AVWLogEntryState();
        static int lockToken;
        notify_register_dispatch("com.apple.springboard.lockstate", &lockToken, dispatch_get_main_queue(), ^(int token) {
            // Both locking and unlocking discard the experimental host. No lock-screen UI.
            [[AVWWindowController shared] close];
        });
        os_log(AVWLog(), "Prototype hooks installed; requires live scene and input testing");
    });
}
