#!/bin/sh
set -eu
: "${APELIN_PACKAGE_DIR:?run through apelin_project_build}"
: "${APELIN_PROJECT_ROOT:?}" "${APELIN_BOOTSTRAP:?}" "${APELIN_ARCHITECTURE:?}"
: "${APELIN_BUILD_ID:?}" "${TMPDIR:?}" "${SDKROOT:?}"
: "${APELIN_PREFIX?}"
cd "${APELIN_PROJECT_ROOT:?}"
mkdir -p .build
work="$(mktemp -d .build/run.XXXXXX)"
stage="$(mktemp -d "${TMPDIR:?}avocado-stage.XXXXXX")"
: "${work:?}" "${stage:?}"
trap 'rm -rf -- "${work:?}" "${stage:?}"' EXIT
case "$APELIN_BOOTSTRAP" in
    roothide) archs="arm64e"; define="-DAPELIN_BOOTSTRAP_ROOTHIDE=1" ;;
    rootless) archs="arm64 arm64e"; define="-DAPELIN_BOOTSTRAP_ROOTLESS=1" ;;
    *) echo 'Unsupported bootstrap' >&2; exit 1 ;;
esac
package_id="$(sed -n 's/^Package: //p' Packaging/control)"
: "${package_id:?}"
for arch in $archs; do
    mkdir -p "$work/$arch"
    for source in Sources/*.m; do
        object="$work/$arch/$(basename "$source" .m).o"
        clang -arch "$arch" -miphoneos-version-min=16.0 -fobjc-arc -fblocks \
            -fvisibility=hidden -Wall -Wextra -Werror -Werror=unguarded-availability-new \
            -Wno-unused-parameter -g -O0 "$define" \
            "-DAPELIN_BUILD_ID=\"$APELIN_BUILD_ID\"" "-DAPELIN_PACKAGE_ID=\"$package_id\"" \
            -c "$source" -o "$object"
    done
    clang -arch "$arch" -miphoneos-version-min=16.0 -dynamiclib \
        -install_name @rpath/AvocadoWindows.dylib \
        -framework Foundation -framework UIKit -framework QuartzCore -framework CoreGraphics \
        "$work/$arch/"*.o -o "$work/$arch.dylib"
done
if [ "$APELIN_BOOTSTRAP" = rootless ]; then
    lipo -create "$work/arm64.dylib" "$work/arm64e.dylib" -output "$work/AvocadoWindows.dylib"
else
    cp "${work:?}/arm64e.dylib" "${work:?}/AvocadoWindows.dylib"
fi
dsymutil "$work/AvocadoWindows.dylib" -o "$APELIN_PACKAGE_DIR/AvocadoWindows.dylib.dSYM"
if [ "${APELIN_CONFIGURATION:-debug}" = release ]; then
    strip -S "$work/AvocadoWindows.dylib"
fi
ldid -S "$work/AvocadoWindows.dylib"
libdir="$stage$APELIN_PREFIX/Library/MobileSubstrate/DynamicLibraries"
mkdir -p "$stage/DEBIAN" "$libdir"
cp Packaging/control "${stage:?}/DEBIAN/control"
printf 'Architecture: %s\n' "$APELIN_ARCHITECTURE" >> "$stage/DEBIAN/control"
cp "${work:?}/AvocadoWindows.dylib" "${libdir:?}/AvocadoWindows.dylib"
cp Packaging/AvocadoWindows.plist "${libdir:?}/AvocadoWindows.plist"
chmod 0644 "$libdir/AvocadoWindows.dylib" "$libdir/AvocadoWindows.plist" "$stage/DEBIAN/control"
dpkg-deb -b --root-owner-group "$stage" "$APELIN_PACKAGE_DIR/AvocadoWindows.deb"
