#import "AVWWindowController.h"
#import "AVWGeometry.h"

@interface AVWPassthroughView : UIView
@end
@implementation AVWPassthroughView
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    return hit == self ? nil : hit;
}
@end

@interface AVWOverlayController : UIViewController
@end
@implementation AVWOverlayController
- (void)loadView { self.view = [[AVWPassthroughView alloc] initWithFrame:CGRectZero]; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskPortrait; }
@end

@interface AVWOverlayWindow : UIWindow
@end
@implementation AVWOverlayWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    return hit == self || hit == self.rootViewController.view ? nil : hit;
}
@end

@interface AVWWindowController () <UIGestureRecognizerDelegate>
@property (nonatomic, strong) AVWOverlayWindow *window;
@property (nonatomic, strong) AVWSceneSession *session;
@property (nonatomic, strong) UIView *chrome;
@property (nonatomic, strong) UIView *bar;
@property (nonatomic, strong) UIView *content;
@property (nonatomic, strong) UIButton *fullButton;
@property (nonatomic, strong) UIButton *minButton;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIButton *resizeHandle;
@property (nonatomic, strong) UIButton *bubble;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) NSTimer *healthTimer;
@property (nonatomic) CGRect dragStartFrame;
@property (nonatomic) CGRect savedFrame;
@property (nonatomic) NSUInteger fadeGeneration;
@property (nonatomic) NSUInteger healthTicks;
@end

@implementation AVWWindowController
+ (instancetype)shared {
    static AVWWindowController *controller;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ controller = [AVWWindowController new]; });
    return controller;
}

- (void)showError:(NSString *)message fromWindow:(UIWindow *)window {
    UIViewController *parent = window.rootViewController;
    while (parent.presentedViewController) parent = parent.presentedViewController;
    if (!parent || AVWLocked()) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"小窗原型" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleCancel handler:nil]];
    [parent presentViewController:alert animated:YES completion:nil];
}

- (UIButton *)button:(NSString *)symbol label:(NSString *)label action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setImage:[UIImage systemImageNamed:symbol] forState:UIControlStateNormal];
    button.tintColor = UIColor.whiteColor;
    button.accessibilityLabel = label;
    button.accessibilityIdentifier = [@"avw." stringByAppendingString:NSStringFromSelector(action)];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (CGRect)availableRect {
    UIEdgeInsets safe = self.window.safeAreaInsets;
    return UIEdgeInsetsInsetRect(self.window.bounds, UIEdgeInsetsMake(MAX(safe.top, 24) + 8, 8, MAX(safe.bottom, 20) + 8, 8));
}

- (void)openSceneHandle:(id)handle fromWindow:(UIWindow *)originalWindow {
    if (!originalWindow.windowScene || AVWLocked()) return;
    [self close];
    NSString *error = nil;
    AVWSceneSession *session = [AVWSceneSession sessionWithHandle:handle sourceWindow:originalWindow error:&error];
    if (!session) { [self showError:error ?: @"无法获取场景。" fromWindow:originalWindow]; return; }
    self.session = session;
    self.window = [[AVWOverlayWindow alloc] initWithWindowScene:originalWindow.windowScene];
    self.window.frame = originalWindow.screen.bounds;
    self.window.backgroundColor = UIColor.clearColor;
    self.window.windowLevel = UIWindowLevelStatusBar + 10;
    self.window.rootViewController = [AVWOverlayController new];
    self.chrome = [UIView new];
    self.chrome.backgroundColor = [UIColor colorWithWhite:0.10 alpha:1];
    self.chrome.layer.cornerRadius = 18;
    self.chrome.clipsToBounds = YES;
    self.chrome.layer.borderColor = [UIColor colorWithWhite:0.5 alpha:0.8].CGColor;
    self.chrome.layer.borderWidth = 1;
    self.chrome.accessibilityIdentifier = @"avw.window";
    [self.window.rootViewController.view addSubview:self.chrome];
    self.content = [UIView new];
    self.content.clipsToBounds = YES;
    self.content.backgroundColor = UIColor.blackColor;
    [self.chrome addSubview:self.content];
    [self.content addSubview:session.hostView];
    self.bar = [UIView new];
    self.bar.backgroundColor = [UIColor colorWithWhite:0.14 alpha:1];
    [self.chrome addSubview:self.bar];
    self.fullButton = [self button:@"arrow.up.left.and.arrow.down.right" label:@"恢复全屏" action:@selector(restoreFullScreen)];
    self.minButton = [self button:@"minus" label:@"最小化小窗" action:@selector(minimize)];
    self.closeButton = [self button:@"xmark" label:@"关闭小窗" action:@selector(close)];
    [self.bar addSubview:self.fullButton];
    [self.bar addSubview:self.minButton];
    [self.bar addSubview:self.closeButton];
    self.titleLabel = [UILabel new];
    self.titleLabel.text = session.title;
    self.titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.textColor = UIColor.whiteColor;
    [self.bar addSubview:self.titleLabel];
    UIPanGestureRecognizer *move = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveWindow:)];
    move.delegate = self;
    [self.bar addGestureRecognizer:move];
    self.resizeHandle = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.resizeHandle setImage:[UIImage systemImageNamed:@"arrow.down.right.and.arrow.up.left"] forState:UIControlStateNormal];
    self.resizeHandle.tintColor = UIColor.systemBlueColor;
    self.resizeHandle.backgroundColor = [UIColor colorWithWhite:0.12 alpha:0.85];
    self.resizeHandle.layer.cornerRadius = 12;
    self.resizeHandle.accessibilityLabel = @"拖动调整小窗大小";
    self.resizeHandle.accessibilityIdentifier = @"avw.resize";
    [self.resizeHandle addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(resizeWindow:)]];
    [self.chrome addSubview:self.resizeHandle];
    self.bubble = [self button:@"app.fill" label:[NSString stringWithFormat:@"恢复%@小窗", session.title] action:@selector(restoreBubble)];
    [self.bubble setImage:nil forState:UIControlStateNormal];
    [self.bubble setTitle:[session.title substringToIndex:MIN((NSUInteger)2, session.title.length)] forState:UIControlStateNormal];
    self.bubble.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    self.bubble.backgroundColor = [UIColor colorWithWhite:0.18 alpha:0.98];
    self.bubble.layer.cornerRadius = 22;
    self.bubble.layer.borderWidth = 1;
    self.bubble.layer.borderColor = UIColor.systemBlueColor.CGColor;
    self.bubble.accessibilityIdentifier = @"avw.bubble";
    self.bubble.hidden = YES;
    [self.bubble addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveBubble:)]];
    [self.window.rootViewController.view addSubview:self.bubble];
    // Do not make this key: keyboard/event focus must remain system managed.
    self.window.hidden = NO;
    [self.window layoutIfNeeded];
    CGRect available = [self availableRect];
    CGSize size = AVWWindowSize(available.size.width * 0.78, session.referenceSize, available);
    self.chrome.frame = CGRectMake(CGRectGetMidX(available) - size.width / 2, CGRectGetMidY(available) - size.height / 2, size.width, size.height);
    [self layoutChrome];
    if (![session start:&error]) {
        [self close];
        [self showError:error ?: @"无法激活场景宿主。" fromWindow:originalWindow];
        return;
    }
    // Optional system home action, guarded because iOS private APIs vary.
    UIApplication *app = UIApplication.sharedApplication;
    if ([app respondsToSelector:@selector(_simulateHomeButtonPress)]) [(id)app _simulateHomeButtonPress];
    __weak typeof(self) weakSelf = self;
    self.healthTicks = 0;
    self.healthTimer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer *timer) {
        AVWWindowController *strongSelf = weakSelf;
        if (!strongSelf || !strongSelf.session) { [timer invalidate]; return; }
        if (AVWLocked() || strongSelf.window.windowScene.interfaceOrientation != UIInterfaceOrientationPortrait) {
            [strongSelf close];
            return;
        }
        strongSelf.healthTicks++;
        if (strongSelf.healthTicks % 5 == 0) {
            id presenter = AVWObject(strongSelf.session.hostView, @"presenter");
            BOOL hosting = [presenter respondsToSelector:@selector(isHosting)] && [presenter isHosting];
            os_log(AVWLog(), "Prototype heartbeat hosting=%d minimized=%d build=%{public}s", hosting, strongSelf.chrome.hidden, APELIN_BUILD_ID);
        }
    }];
}

- (void)layoutChrome {
    CGFloat width = self.chrome.bounds.size.width;
    CGFloat height = self.chrome.bounds.size.height;
    self.bar.frame = CGRectMake(0, 0, width, 44);
    self.fullButton.frame = CGRectMake(0, 0, 44, 44);
    self.minButton.frame = CGRectMake(44, 0, 44, 44);
    self.closeButton.frame = CGRectMake(width - 44, 0, 44, 44);
    self.titleLabel.frame = CGRectMake(88, 0, MAX(0, width - 132), 44);
    self.content.frame = CGRectMake(0, 44, width, MAX(0, height - 44));
    UIView *host = self.session.hostView;
    host.transform = CGAffineTransformIdentity;
    host.bounds = (CGRect){CGPointZero, self.session.referenceSize};
    host.center = CGPointMake(CGRectGetMidX(self.content.bounds), CGRectGetMidY(self.content.bounds));
    CGFloat scale = width / MAX(1, self.session.referenceSize.width);
    host.transform = CGAffineTransformMakeScale(scale, scale);
    self.resizeHandle.frame = CGRectMake(width - 30, height - 30, 30, 30);
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gesture shouldReceiveTouch:(UITouch *)touch {
    for (UIView *view = touch.view; view && view != self.bar; view = view.superview) {
        if ([view isKindOfClass:UIControl.class]) return NO;
    }
    return YES;
}

- (void)moveWindow:(UIPanGestureRecognizer *)pan {
    if (pan.state == UIGestureRecognizerStateBegan) self.dragStartFrame = self.chrome.frame;
    CGPoint delta = [pan translationInView:self.window.rootViewController.view];
    CGRect frame = self.dragStartFrame;
    frame.origin.x += delta.x;
    frame.origin.y += delta.y;
    self.chrome.frame = AVWConstrainFrame(frame, [self availableRect]);
}

- (void)resizeWindow:(UIPanGestureRecognizer *)pan {
    if (pan.state == UIGestureRecognizerStateBegan) self.dragStartFrame = self.chrome.frame;
    CGPoint delta = [pan translationInView:self.window.rootViewController.view];
    CGRect available = [self availableRect];
    CGRect frame = self.dragStartFrame;
    frame.size = AVWWindowSize(frame.size.width + delta.x, self.session.referenceSize, available);
    self.chrome.frame = AVWConstrainFrame(frame, available);
    [self layoutChrome];
}

- (void)fadeBubbleLater {
    self.bubble.alpha = 1;
    NSUInteger generation = ++self.fadeGeneration;
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        AVWWindowController *strongSelf = weakSelf;
        if (!strongSelf || generation != strongSelf.fadeGeneration || strongSelf.bubble.hidden) return;
        [UIView animateWithDuration:0.3 animations:^{ strongSelf.bubble.alpha = 0.35; }];
    });
}

- (void)minimize {
    if (!self.session || AVWLocked()) return;
    self.savedFrame = self.chrome.frame;
    [self.session setMinimized:YES];
    self.chrome.hidden = YES;
    self.bubble.hidden = NO;
    CGRect available = [self availableRect];
    BOOL right = CGRectGetMidX(self.savedFrame) >= CGRectGetMidX(self.window.bounds);
    self.bubble.frame = CGRectMake(right ? self.window.bounds.size.width - 44 : -8,
                                  AVWClamp(CGRectGetMidY(self.savedFrame) - 26, CGRectGetMinY(available), CGRectGetMaxY(available) - 52), 52, 52);
    [self fadeBubbleLater];
}

- (void)restoreBubble {
    if (AVWLocked()) { [self close]; return; }
    self.fadeGeneration++;
    self.bubble.hidden = YES;
    self.chrome.hidden = NO;
    self.chrome.frame = AVWConstrainFrame(self.savedFrame, [self availableRect]);
    [self.session setMinimized:NO];
}

- (void)moveBubble:(UIPanGestureRecognizer *)pan {
    if (pan.state == UIGestureRecognizerStateBegan) {
        self.dragStartFrame = self.bubble.frame;
        self.fadeGeneration++;
        self.bubble.alpha = 1;
    }
    CGPoint delta = [pan translationInView:self.window.rootViewController.view];
    CGRect frame = self.dragStartFrame;
    CGRect available = [self availableRect];
    frame.origin.x = AVWClamp(frame.origin.x + delta.x, -8, self.window.bounds.size.width - 44);
    frame.origin.y = AVWClamp(frame.origin.y + delta.y, CGRectGetMinY(available), CGRectGetMaxY(available) - 52);
    if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        frame.origin.x = CGRectGetMidX(frame) < CGRectGetMidX(self.window.bounds) ? -8 : self.window.bounds.size.width - 44;
        [self fadeBubbleLater];
    }
    self.bubble.frame = frame;
}

- (void)restoreFullScreen {
    if (AVWLocked()) { [self close]; return; }
    UIApplication *app = UIApplication.sharedApplication;
    if (![app respondsToSelector:@selector(launchApplicationWithIdentifier:suspended:)]) {
        [self showError:@"全屏恢复接口不可用，请关闭小窗后从桌面打开应用。" fromWindow:self.window];
        return;
    }
    NSString *bundle = self.session.bundleIdentifier;
    [self close];
    [(id)app launchApplicationWithIdentifier:bundle suspended:NO];
}

- (void)close {
    [self.healthTimer invalidate];
    self.healthTimer = nil;
    self.fadeGeneration++;
    [self.session stop];
    self.session = nil;
    self.window.hidden = YES;
    self.window.rootViewController = nil;
    self.window = nil;
    self.chrome = nil;
    self.bar = nil;
    self.content = nil;
    self.fullButton = nil;
    self.minButton = nil;
    self.closeButton = nil;
    self.resizeHandle = nil;
    self.bubble = nil;
    self.titleLabel = nil;
}
@end
