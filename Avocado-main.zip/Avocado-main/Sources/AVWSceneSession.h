#pragma once
#import "AVWPrivate.h"

@interface AVWSceneSession : NSObject
@property (nonatomic, strong, readonly) UIView *hostView;
@property (nonatomic, strong, readonly) id scene;
@property (nonatomic, copy, readonly) NSString *bundleIdentifier;
@property (nonatomic, copy, readonly) NSString *title;
@property (nonatomic, readonly) CGSize referenceSize;
@property (nonatomic, readonly) BOOL active;
+ (instancetype)currentSession;
+ (instancetype)sessionWithHandle:(id)handle sourceWindow:(UIWindow *)window error:(NSString **)error;
+ (void)observeSystemDisplayMode:(NSInteger)mode;
+ (BOOL)getSystemLiveDisplayMode:(NSInteger *)mode;
- (BOOL)start:(NSString **)error;
- (void)setMinimized:(BOOL)minimized;
- (void)stop;
// Called only by the narrowly conditional FBScene hook.
- (id)settingsForSystemRequest:(id)settings;
@end
