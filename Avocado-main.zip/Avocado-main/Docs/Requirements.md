# iOS 16 Floating Window Requirements

Reference: the six images attached to the original requirements conversation.

## Target interaction
- An action at the **upper-right of each app-switcher card** opens that app as a live floating window.
- The window title bar offers full-screen restore, minimize and close. Drag its title bar to move it; resize using a dedicated corner handle.
- Minimize to an app bubble attached to the nearest screen edge. Fade when idle; tap to restore.
- Swipe inward from either screen edge and hold to reveal an app sidebar. Tap an app to open a window.
- Long-press and drag a sidebar app into the center to select split-screen or floating mode.
- A bottom add button opens app selection and manages pinned sidebar apps.

## Delivery sequence
1. Validate one existing app scene as a live, touchable floating window on iOS 16.6.1. Start with Settings; do not use Apelin as the test app. Preserve a way to return the scene to normal.
2. Add window chrome, movement, proportional resizing and minimize/restore.
3. Add edge gestures, app sidebar and pinned app selection.
4. Investigate split-screen separately: support is not assumed on iPhone.

## Current limitations
No functional behavior has been tested yet. Keyboard routing, landscape, cold launch, multiple windows, lock transitions and third-party apps require device verification. Never substitute snapshots for a working live host or claim they provide interaction.
