#pragma once
#import <UIKit/UIKit.h>
#import <os/log.h>
#import <QuartzCore/QuartzCore.h>
#include <string.h>

#ifndef APELIN_PACKAGE_ID
#define APELIN_PACKAGE_ID "local.apelin.avocado.windows"
#endif
#ifndef APELIN_BUILD_ID
#define APELIN_BUILD_ID "development"
#endif

static inline os_log_t AVWLog(void) {
    static os_log_t log;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "windows"); });
    return log;
}

// Runtime-only private declarations. Never link SpringBoard into a helper.
@interface NSObject (AVWPrivateInterfaces)
- (id)sceneHandle;
- (id)application;
- (NSString *)bundleIdentifier;
- (NSString *)displayName;
- (id)scene;
- (id)settings;
- (void)updateSettings:(id)settings withTransitionContext:(id)context completion:(id)completion;
- (UIView *)newSceneViewWithReferenceSize:(CGSize)size orientation:(NSInteger)orientation hostRequester:(NSString *)requester;
- (UIView *)newSceneViewWithReferenceSize:(CGSize)size contentOrientation:(NSInteger)content containerOrientation:(NSInteger)container hostRequester:(NSString *)requester;
- (BOOL)isUILocked;
+ (instancetype)sharedInstance;
- (void)setForeground:(BOOL)value;
- (void)setBackgrounded:(BOOL)value;
- (void)setOccluded:(BOOL)value;
- (void)setActive:(BOOL)value;
- (void)setVisible:(BOOL)value;
- (void)invalidate;
- (NSInteger)displayMode;
- (void)setDisplayMode:(NSInteger)mode animationFactory:(id)factory completion:(id)completion;
- (void)setResizesHostedContext:(BOOL)resizes;
- (BOOL)isActive;
- (BOOL)isHosting;
- (BOOL)isInvalidated;
- (void)activate;
- (void)deactivate;
- (BOOL)launchApplicationWithIdentifier:(NSString *)identifier suspended:(BOOL)suspended;
- (void)_simulateHomeButtonPress;
- (NSInteger)layoutRoleForItem:(id)item;
- (id)_sceneHandleForRole:(NSInteger)role;
- (NSString *)sceneIdentifierForBundleIdentifier:(NSString *)bundle uniqueIdentifier:(NSString *)unique;
- (id)sceneWithIdentifier:(NSString *)identifier;
- (id)existingSceneHandleForScene:(id)scene;
@end

static inline id AVWObject(id object, NSString *name) {
    SEL sel = NSSelectorFromString(name);
    if (![object respondsToSelector:sel]) return nil;
    NSMethodSignature *sig = [object methodSignatureForSelector:sel];
    if (sig.numberOfArguments != 2 || sig.methodReturnType[0] != '@') return nil;
    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
    inv.selector = sel;
    inv.target = object;
    [inv invoke];
    __unsafe_unretained id result = nil;
    [inv getReturnValue:&result];
    return result;
}

static inline BOOL AVWLocked(void) {
    id manager = AVWObject(NSClassFromString(@"SBLockScreenManager"), @"sharedInstance");
    // Fail closed when the lock-state interface is unavailable.
    if (![manager respondsToSelector:@selector(isUILocked)]) return YES;
    return [manager isUILocked];
}
