#pragma once
#import "AVWSceneSession.h"

@interface AVWWindowController : NSObject
+ (instancetype)shared;
- (void)openSceneHandle:(id)handle fromWindow:(UIWindow *)window;
- (void)close;
@end
