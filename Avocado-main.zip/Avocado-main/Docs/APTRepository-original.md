# 原软件源说明（历史存档）

以下为迁移前的原始说明，旧 GSA 地址不再作为小窗软件源使用。
当前小窗仓库是 `xuezhixiatongsheng/Avocado`；Pages 尚未启用，部署工作流已改为手动运行。
文中旧自动发布步骤仅作历史参考，当前操作以根目录 README 为准。

## 原文：xuezhixiatongsheng/GSA-

An APT source for jailbroken iOS, published with Apelin.

Add `https://xuezhixiatongsheng.github.io/GSA-/` in Irisin.

## How it works

- Packages are the `.deb` files in `debs/`, named
  `<Package>_<Version>_<Architecture>.deb`. Apelin's Distribute… page
  publishes a release build here; a `.deb` pushed by hand works the same.
- On every push to `main`, `.github/workflows/update-repository.yml` runs
  `scripts/update-repository.sh`, which indexes `debs/` into `Packages`,
  `Packages.xz` and `Release`, and publishes the site to GitHub Pages.
  Never commit those indexes or `_site/`.
- `depictions/<package id>/` holds a package's depiction, icon and
  banner; `sileo-featured.json` the banners Irisin shows at the top of the
  source; `CydiaIcon.png`, when present, the source's icon.

Pages may serve the previous index for up to ten minutes after a push.
