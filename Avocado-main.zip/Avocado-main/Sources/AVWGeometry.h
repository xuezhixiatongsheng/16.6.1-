#pragma once
#import <CoreGraphics/CoreGraphics.h>
#include <math.h>

static inline bool AVWIsSwitcherCardFrame(CGRect frame, CGRect bounds) {
    return isfinite(frame.origin.x) && isfinite(frame.origin.y) &&
        isfinite(frame.size.width) && isfinite(frame.size.height) &&
        !CGRectIsEmpty(frame) && CGRectIntersectsRect(frame, bounds) &&
        frame.size.width < bounds.size.width * 0.95 &&
        frame.size.height < bounds.size.height * 0.95;
}

static inline CGFloat AVWClamp(CGFloat n, CGFloat lo, CGFloat hi) {
    return fmin(fmax(n, lo), fmax(lo, hi));
}
static inline CGSize AVWWindowSize(CGFloat width, CGSize reference, CGRect available) {
    CGFloat ratio = reference.width > 0 ? reference.height / reference.width : 2;
    if (!isfinite(ratio) || ratio <= 0) ratio = 2;
    CGFloat maxWidth = fmax(1, fmin(available.size.width, fmax(1, available.size.height - 44) / ratio));
    CGFloat minWidth = fmin(180, maxWidth);
    width = AVWClamp(width, minWidth, maxWidth);
    return CGSizeMake(width, width * ratio + 44);
}
static inline CGRect AVWConstrainFrame(CGRect frame, CGRect available) {
    frame.origin.x = AVWClamp(frame.origin.x, CGRectGetMinX(available), CGRectGetMaxX(available) - frame.size.width);
    frame.origin.y = AVWClamp(frame.origin.y, CGRectGetMinY(available), CGRectGetMaxY(available) - frame.size.height);
    return frame;
}
